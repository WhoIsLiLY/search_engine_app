from sklearn.preprocessing import Binarizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

def calculateSimilarity(preprocessing, keyword):

    data = [preprocessing,keyword]
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(data).toarray()
    total = len(tfidf_matrix)
    

    for i in range(total - 1):
        num = 0.0
        denom_wkq = 0.0

        for x in range(len(tfidf_matrix[i])):
            num += min(tfidf_matrix[total - 1][x], tfidf_matrix[i][x])
            denom_wkq += tfidf_matrix[total - 1][x]

        result = num / denom_wkq if denom_wkq != 0 else 0

    tfidf = TfidfVectorizer(norm = None, sublinear_tf=True)
    vector_tfidf = tfidf.fit_transform(data)
    
    for i in range(len(data)-1):
        dist = cosine_similarity(vector_tfidf[i], vector_tfidf[len(data)-1])
	
    return f"assimetric {(np.round(result, 2))} and Cosine = {np.round(dist,2)}"